-- SQL Queries for PhonePe Project
-- 1. Total Transactions by State
SELECT state, SUM(transaction_amount) AS total
FROM aggregated_transaction
GROUP BY state
ORDER BY total DESC;