import streamlit as st
import pandas as pd
import plotly.express as px

st.title("📱 PhonePe Transactions Dashboard")

df = pd.read_csv("data/cleaned_aggregated_transaction.csv")

state = st.sidebar.selectbox("Select a State", df["state"].unique())

filtered_data = df[df["state"] == state]

st.subheader(f"Transaction Trend in {state}")
fig = px.bar(filtered_data, x="payment_category", y="transaction_amount", color="payment_category")
st.plotly_chart(fig)
