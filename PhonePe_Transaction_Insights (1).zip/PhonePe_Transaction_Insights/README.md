# 📱 PhonePe Transaction Insights

This project analyzes PhonePe's digital payment data using SQL, Python, and Streamlit.

## Components
- EDA
- SQL Queries
- Streamlit Dashboard
- Insights Report
- Presentation Slides
