# 🔍 PhonePe Transaction Insights – Summary

## 📈 Key Findings:
- Maharashtra and Karnataka show highest transaction volumes.
- Insurance data reveals urban concentration.

## 📌 Recommendations:
- Focus marketing on Tier-2 cities.
